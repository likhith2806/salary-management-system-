Salary Management System:
---------------------------------------

Introduction:
-----------------
*This project is based on accounts concept.
*Salary Management System is a DataBase system which can be used for managing employee Salary Details.
*It is a multi-user system and can be used by hundreds of user at the same time.
*Generally speaking, it is platform available for running on a local area network(LAN).


Goals:
---------
*Managing Information on Employees
*Employees Salary Details
*Result Processing
*Reports
*etc


Software is as follows:
------------------------------
*Microsoft  Visual Studio 2010
*Microsoft  SQL Server 2008 
*Crystal Reports 2008
*MS Office 2007


Ms SQL DataBase BackUp File Location :- SalaryManagementSystem\SQL DataBase BackUp File\ 
After restored DataBase, Please update SQL server password in connection string.


If you want some another help, Join me on (http://m.facebook.com/hasan.soherwardi)
OR (hasan.net55@gmail.com) Contact no: +91-9731881745

Special thanks to "SourceCodeSter" Its my best guide...